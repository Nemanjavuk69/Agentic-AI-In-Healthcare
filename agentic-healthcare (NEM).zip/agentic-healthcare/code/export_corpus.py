"""
export_corpus.py — Export deptriage.dk chunks from ChromaDB to a plain text file.

Run from the code/ directory:
    python export_corpus.py

This produces dept_corpus.txt in the same directory, with one chunk per line.
That file is consumed by two things:
  1. privacy_eval/detectors/l5_memorization.py (set corpus_path in config.yaml)
  2. phase3_memorization.py (the memorization probe script)

You only need to run this once, or again if you rebuild the ChromaDB database.
"""

import chromadb
import json
import os

CHROMA_PATH   = "./dept_db"
OUTPUT_FILE   = "./dept_corpus.txt"
COLLECTION    = "dept_guidelines"      # adjust if your collection has a different name


def export_corpus() -> None:
    if not os.path.exists(CHROMA_PATH):
        print(f"[ERROR] ChromaDB not found at '{CHROMA_PATH}'. "
              f"Make sure you are running this from the code/ directory.")
        return

    print(f"Connecting to ChromaDB at '{CHROMA_PATH}'...")
    client     = chromadb.PersistentClient(path=CHROMA_PATH)

    try:
        collection = client.get_collection(COLLECTION)
    except Exception:
        # List available collections so the user can correct the name.
        available = [c.name for c in client.list_collections()]
        print(f"[ERROR] Collection '{COLLECTION}' not found.")
        print(f"        Available collections: {available}")
        print(f"        Edit the COLLECTION variable at the top of this script.")
        return

    print("Fetching all chunks...")
    result = collection.get(include=["documents"])
    docs   = result.get("documents", [])

    if not docs:
        print("[WARNING] No documents found in the collection.")
        return

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for doc in docs:
            # Replace internal newlines so each chunk stays on one line.
            line = doc.replace("\n", " ").strip()
            if line:
                f.write(line + "\n")

    print(f"Exported {len(docs)} chunks to '{OUTPUT_FILE}'.")
    print(f"Shortest chunk : {min(len(d) for d in docs)} chars")
    print(f"Longest chunk  : {max(len(d) for d in docs)} chars")
    print(f"Average length : {int(sum(len(d) for d in docs) / len(docs))} chars")
    print(f"\nNext step: run phase3_memorization.py")


if __name__ == "__main__":
    export_corpus()