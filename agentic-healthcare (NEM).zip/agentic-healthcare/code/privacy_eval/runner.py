"""
runner.py — Orchestration layer for the privacy_eval package.

Usage
-----
    from privacy_eval.runner import PrivacyEvalRunner
    from privacy_eval.schemas import PatientContext

    runner = PrivacyEvalRunner(config_path="privacy_eval/config.yaml")

    context = PatientContext(
        patient_id="42",
        name="Gitte Knudsen",
        age=45,
        gender="Female",
        postalcode="8000",
        system_prompt=system_prompt_str,
        user_prompt=user_input_str,
        visit_history=visit_history_str,
        dept_context=dept_context_str,
        all_records=triage_json_list,
    )

    record = runner.evaluate(response=llm_response, context=context)
    print(record.overall_fail)          # True / False
    runner.write(record)                # appends to JSONL log

The runner is designed to be called from Phase 4's batch script. It has
no dependency on agent1.py; agent1.py can call it optionally if we later
want live evaluation.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
import yaml
from datetime import datetime, timezone

from .detectors.l1_pii_echo import L1DirectPIIEcho
from .detectors.l2_cross_patient import L2CrossPatientContamination
from .detectors.l3_exfiltration import L3ContextExfiltration
from .detectors.l4_inferential import L4InferentialLeakage
from .detectors.l5_memorization import L5Memorization
from .schemas import EvaluationRecord, PatientContext


class PrivacyEvalRunner:

    def __init__(self, config_path: str = "privacy_eval/config.yaml"):
        with open(config_path, encoding="utf-8") as f:
            self.config: dict = yaml.safe_load(f)

        self._detectors = [
            L1DirectPIIEcho(),
            L2CrossPatientContamination(),
            L3ContextExfiltration(),
            L4InferentialLeakage(),
            L5Memorization(),
        ]

        self._output_path: str = (
            self.config.get("logging", {}).get(
                "output_path", "./logs/privacy_eval_results.jsonl"
            )
        )
        os.makedirs(os.path.dirname(self._output_path), exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        response: str,
        context: PatientContext,
    ) -> EvaluationRecord:
        """
        Run all five detectors against a single prompt-response pair.
        Returns an EvaluationRecord with one verdict per detector.
        """
        verdicts = [
            detector.run(response, context, self.config)
            for detector in self._detectors
        ]

        overall_fail = any(v.verdict == "fail" for v in verdicts)

        record = EvaluationRecord(
            run_id=str(uuid.uuid4()),
            patient_id=context.patient_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            prompt_snippet=context.user_prompt[:120],
            verdicts=verdicts,
            overall_fail=overall_fail,
        )

        return record

    def write(self, record: EvaluationRecord) -> None:
        """Append an EvaluationRecord to the JSONL output file."""
        with open(self._output_path, "a", encoding="utf-8") as f:
            f.write(record.to_json() + "\n")

    def evaluate_and_write(
        self,
        response: str,
        context: PatientContext,
    ) -> EvaluationRecord:
        """Convenience method: evaluate then immediately write to disk."""
        record = self.evaluate(response, context)
        self.write(record)
        return record

    # ------------------------------------------------------------------
    # Utility: load from the agent1 interaction log
    # ------------------------------------------------------------------

    @staticmethod
    def load_interaction_log(log_path: str) -> list[dict]:
        """
        Read the JSONL file that agent1.py writes, returning a list of
        interaction dicts ready for the batch runner in Phase 4.
        """
        if not os.path.exists(log_path):
            return []
        records = []
        with open(log_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return records

    @staticmethod
    def _prompt_hash(prompt: str) -> str:
        return hashlib.sha256(prompt.encode()).hexdigest()[:16]