"""
schemas.py — shared data classes for the privacy_eval package.

Every detector returns a DetectorVerdict. The runner wraps all five
into an EvaluationRecord and writes it to disk. PatientContext carries
everything a detector needs to know about the current patient and the
data environment it sits in.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class PatientContext:
    """
    Everything the detectors need to know about the patient being assessed
    and the surrounding data environment.

    system_prompt   : the full system prompt string that was sent to qwen,
                      including the visit_history block and the DEPT context.
    user_prompt     : the raw symptom description from the user.
    visit_history   : the formatted visit history string that was embedded
                      inside system_prompt, kept separately so L3 can match
                      against it directly.
    dept_context    : the DEPT guideline excerpts retrieved for this query,
                      also kept separately for L3.
    all_records     : the complete triage.json list, used by L2 to look up
                      every other patient's data.
    """
    patient_id: str
    name: str
    age: int | None
    gender: str
    postalcode: str
    system_prompt: str
    user_prompt: str
    visit_history: str
    dept_context: str
    all_records: list[dict] = field(default_factory=list)


@dataclass
class DetectorVerdict:
    """
    The output of a single detector for a single prompt-response pair.

    detector_id : "L1" through "L5"
    label       : human-readable name matching the spec
    verdict     : "pass" or "fail"
    evidence    : the substrings or patterns that triggered a failure;
                  empty list if verdict is "pass"
    confidence  : "high", "medium", or "low" — reflects how reliable this
                  detector's signal is (L4 is typically "medium")
    metadata    : detector-specific extras, e.g. which other patient's record
                  the L2 hit came from
    """
    detector_id: str
    label: str
    verdict: str
    evidence: list[str] = field(default_factory=list)
    confidence: str = "high"
    metadata: dict[str, Any] = field(default_factory=dict)

    def passed(self) -> bool:
        return self.verdict == "pass"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class EvaluationRecord:
    """
    One complete evaluation: a single prompt-response pair run through all
    five detectors. This is the unit the runner writes to the JSONL log.
    """
    run_id: str
    patient_id: str
    timestamp: str
    prompt_snippet: str        # first 120 chars of user_prompt, for readability
    verdicts: list[DetectorVerdict] = field(default_factory=list)
    overall_fail: bool = False  # True if any detector returned "fail"

    def to_dict(self) -> dict:
        d = asdict(self)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)