"""
base.py — abstract base class for all privacy detectors.

Every detector inherits from BaseDetector, implements the run() method,
and returns a DetectorVerdict. The base class provides shared helpers
for normalised substring matching so the individual detectors stay lean.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod

from .schemas import DetectorVerdict, PatientContext


class BaseDetector(ABC):
    """
    All detectors share the same interface:
        verdict = detector.run(response, context, config)

    response : the raw string returned by qwen for this query
    context  : a PatientContext describing the patient and prompt environment
    config   : the dict loaded from config.yaml (full document, not a subtree)
    """

    DETECTOR_ID: str = ""
    LABEL: str = ""

    @abstractmethod
    def run(
        self,
        response: str,
        context: PatientContext,
        config: dict,
    ) -> DetectorVerdict:
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def contains_substring(
        haystack: str,
        needle: str,
        case_sensitive: bool = False,
    ) -> bool:
        """Return True if needle appears anywhere in haystack."""
        if not needle or not needle.strip():
            return False
        if not case_sensitive:
            return needle.lower() in haystack.lower()
        return needle in haystack

    @staticmethod
    def find_substrings(
        haystack: str,
        needles: list[str],
        case_sensitive: bool = False,
    ) -> list[str]:
        """Return the subset of needles that appear in haystack."""
        found = []
        for needle in needles:
            if not needle or not needle.strip():
                continue
            check_h = haystack if case_sensitive else haystack.lower()
            check_n = needle if case_sensitive else needle.lower()
            if check_n in check_h:
                found.append(needle)
        return found

    @staticmethod
    def split_into_sentences(text: str) -> list[str]:
        """
        Lightweight sentence splitter. Good enough for detecting
        quasi-identifier co-occurrence in L4; not a substitute for spaCy
        if we need linguistic accuracy later.
        """
        # Split on . ! ? followed by whitespace or end-of-string,
        # but keep the delimiter attached so the sentence is readable.
        parts = re.split(r"(?<=[.!?])\s+", text.strip())
        return [p for p in parts if p.strip()]

    @staticmethod
    def word_ngrams(text: str, n: int) -> list[str]:
        """
        Return all n-word contiguous spans from text, lowercased.
        Used by L2 to scan for symptom-string matches.
        """
        words = text.lower().split()
        if len(words) < n:
            return []
        return [" ".join(words[i : i + n]) for i in range(len(words) - n + 1)]

    @staticmethod
    def pass_verdict(detector_id: str, label: str) -> DetectorVerdict:
        return DetectorVerdict(
            detector_id=detector_id,
            label=label,
            verdict="pass",
        )

    @staticmethod
    def fail_verdict(
        detector_id: str,
        label: str,
        evidence: list[str],
        confidence: str = "high",
        metadata: dict | None = None,
    ) -> DetectorVerdict:
        return DetectorVerdict(
            detector_id=detector_id,
            label=label,
            verdict="fail",
            evidence=evidence,
            confidence=confidence,
            metadata=metadata or {},
        )