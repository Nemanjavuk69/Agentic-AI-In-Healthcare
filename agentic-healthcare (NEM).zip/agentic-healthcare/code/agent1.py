import json
import os
import uuid
from datetime import datetime, timezone
from utils import call_llm, retrieve_dept_context

# =========================
# Interaction logging
# Every prompt-response pair is written to a JSONL file so the offline
# privacy evaluation tool (privacy_eval/) can analyse it without having
# to re-run the model. The log is append-only; nothing is ever deleted.
# =========================

INTERACTION_LOG = "./logs/agent1_interactions.jsonl"


def log_interaction(
    patient_id: str,
    system_prompt: str,
    user_prompt: str,
    response: str,
    visit_history: str,
    dept_context: str,
) -> None:
    """Append one prompt-response pair to the interaction log."""
    os.makedirs(os.path.dirname(INTERACTION_LOG), exist_ok=True)
    record = {
        "run_id":        str(uuid.uuid4()),
        "timestamp":     datetime.now(timezone.utc).isoformat(),
        "patient_id":    str(patient_id),
        "system_prompt": system_prompt,
        "user_prompt":   user_prompt,
        "response":      response,
        "visit_history": visit_history,
        "dept_context":  dept_context,
    }
    with open(INTERACTION_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# Routing threshold
# Patients with triage score <= THRESHOLD go to Agent 2 (emergency)
# Patients with triage score >  THRESHOLD go to Agent 3 (follow-up)
# Change this number to adjust routing behaviour
# =========================

TRIAGE_THRESHOLD = 2
TRIAGE_JSON      = "triage.json"
HOSPITAL_NAME    = "Aalborg University Hospital"


# =========================
# EHR helpers
# triage.json is now the single source of truth: each entry is one visit
# and contains the patient's id, name, age, gender, postalcode, and Symptoms.
# =========================

def load_triage_records() -> list[dict]:
    """Load all triage records from triage.json."""
    if not os.path.exists(TRIAGE_JSON):
        return []
    with open(TRIAGE_JSON, encoding="utf-8") as f:
        return json.load(f)


def save_triage_records(records: list[dict]):
    """Write the full record list back to triage.json."""
    with open(TRIAGE_JSON, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)


def find_patient(patient_id: str, records: list[dict]) -> dict | None:
    """
    Look up the most recent record for a patient ID and return their
    demographic info. Returns None if no record exists for this ID.
    """
    matches = [r for r in records if str(r.get("id", "")) == str(patient_id)]
    if not matches:
        return None
    return matches[-1]   # most recent visit


def load_past_visits(patient_id: str, records: list[dict]) -> list[dict]:
    """Return all records matching the given patient ID."""
    return [r for r in records if str(r.get("id", "")) == str(patient_id)]


def format_visits_for_prompt(visits: list[dict]) -> str:
    """Convert past visit records into a readable summary for the LLM."""
    if not visits:
        return "No previous visits on record. This is the patient's first visit."
    lines = []
    for i, v in enumerate(visits, 1):
        lines.append(f"  Visit {i}: symptoms='{v.get('Symptoms', 'N/A')}'")
    return "\n".join(lines)


def append_visit(patient: dict, symptoms: str):
    """Append a new visit record to triage.json."""
    record = {
        "id":         str(patient["id"]),
        "name":       patient.get("name", ""),
        "age":        patient.get("age"),
        "gender":     patient.get("gender", ""),
        "postalcode": patient.get("postalcode", ""),
        "Symptoms":   symptoms[:200]   # cap length for safety
    }

    records = load_triage_records()
    records.append(record)
    save_triage_records(records)

    print(f"\n[System] Visit appended to {TRIAGE_JSON} (id={patient['id']})\n")


# =========================
# Step 1: Symptom Classifier
# =========================

def is_symptom_input(user_input: str) -> bool:
    system_prompt = """
You are a medical intake classifier.

Your only job is to decide if the user's message contains medical symptoms,
health complaints, or a description of how a patient is feeling physically or mentally.

Examples of symptom input:
- "My chest is burning"
- "I have had a headache for 3 days"
- "The patient is vomiting and has a fever"

Examples of NON-symptom input:
- "Hello"
- "What can you help me with?"
- "Who are you?"

Respond with ONLY one word: YES or NO.
"""
    user_prompt = f"Does this message contain medical symptoms?\n\n\"{user_input}\""
    result = call_llm(system_prompt, user_prompt).strip().upper()
    return result.startswith("YES")


# =========================
# Step 2: Triage Agent
# Uses retrieved DEPT context and past visit history to assign a triage score
# =========================

def triage_agent(user_input: str, visit_history: str, patient_id: str = "") -> dict:
    dept_context = retrieve_dept_context(user_input)

    system_prompt = f"""
You are a medical triage assistant trained on Danish DEPT (Danish Emergency Process Triage) guidelines.

You will receive:
1. A patient's symptom description
2. Relevant excerpts from the official DEPT triage guidelines
3. The patient's past ED visit history

When assessing urgency, take the patient's history into account. For example, a patient with a
previous high-acuity visit for chest pain should be treated with extra caution if presenting
with similar symptoms again.

Patient history from previous ED visits:
{visit_history}

Your job is to:
1. Write 2-3 sentences explaining your assessment of the symptoms based on the DEPT guidelines
   and the patient's history.
2. Assign a triage color on this exact scale:
   - 1 RØD    - Immediately life-threatening
   - 2 ORANGE - Urgent, potentially life-threatening
   - 3 GUL    - Urgent but stable
   - 4 GRØN   - Less urgent
   - 5 BLÅ    - Non-urgent

Always end your response with this exact line and nothing after it:
Triage level: [NUMBER] [COLOR]

Example ending: Triage level: 2 ORANGE
"""

    user_prompt = f"""Patient symptoms:
{user_input}

Relevant DEPT guidelines:
{dept_context}
"""

    response = call_llm(system_prompt, user_prompt)

    # Log the full prompt-response pair so the offline privacy eval tool
    # can analyse it without re-running the model.
    log_interaction(
        patient_id=patient_id,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        response=response,
        visit_history=visit_history,
        dept_context=dept_context,
    )

    # Extract triage score from the last line
    score = None
    for line in response.splitlines():
        if line.strip().startswith("Triage level:"):
            try:
                score = int(line.strip().split()[2])
            except (IndexError, ValueError):
                pass

    return {
        "response": response,
        "score": score,
        "symptoms": user_input
    }


# =========================
# Step 3: Routing
# =========================

def route(triage_result: dict, patient: dict):
    score    = triage_result["score"]
    symptoms = triage_result["symptoms"]
    response = triage_result["response"]

    # Always append the visit, regardless of routing outcome
    append_visit(patient, symptoms)

    if score is None:
        print("Could not determine triage score. Please try again.\n")
        return

    if score <= TRIAGE_THRESHOLD:
        print(f"Triage score {score} is critical. Routing to Agent 2 (Emergency Response Team).")
        from agent2 import run_agent as run_agent2

        emergency_data = {
            "patient_id": patient["id"],
            "symptoms":   symptoms,
            "score":      score,
            "location":   patient.get("postalcode", "")
        }
        result = run_agent2(emergency_data)

        if isinstance(result, dict):
            print(f"\nMessage: {result.get('message', 'N/A')}")
            print(f"Hospital: {result.get('hospital', 'N/A')}")
            print(f"Department: {result.get('department', 'N/A')}")
            print(f"Address: {result.get('address', 'N/A')}")
            if result.get('transport'):
                print(f"Transport: {result.get('transport').upper()}")
        else:
            print(result)

    else:
        print(f"Triage score {score}. Routing to Agent 3 (Medical Follow-up).\n")
        print("\n" + "─" * 85)
        from agent3 import run_agent as run_agent3
        triage_input = {
            "summary": symptoms,
            "urgency": response
        }
        run_agent3(triage_input=triage_input, patient_id=patient["id"])


# =========================
# Main interactive loop
# =========================

def main():
    print("\n" + "=" * 85)
    print(" " * 28 + "DEPT TRIAGE ASSISTANT")
    print("\n" + "=" * 85)
    print("""\nWelcome to the DEPT Triage Assistant. 
        \nMy purpose is to quickly and accurately assess the urgency of medical complaints using the official Danish DEPT triage system.
        \nBased on the symptoms you describe, I will:
        \n- Determine the appropiate triage level
        \n- Route critical cases directly to emergency services
        \n- Provide follow-up advice for less urgent cases
          """)

    print("\n" + "─" * 85)

    # Load all triage records up front so we can do lookups
    records = load_triage_records()

    # Ask for patient ID
    patient_id = ""
    while not patient_id:
        patient_id = input("\nPlease enter the patient's ID: ").strip()
        if not patient_id:
            print("Patient ID cannot be empty. Please try again.")

    # Look up existing record
    existing = find_patient(patient_id, records)

    if existing:
        patient = {
            "id":         str(patient_id),
            "name":       existing.get("name", ""),
            "age":        existing.get("age"),
            "gender":     existing.get("gender", ""),
            "postalcode": existing.get("postalcode", "")
        }
        print(f"\n[System] Found existing record for patient {patient_id}: "
              f"{patient['name']}, age {patient['age']}, "
              f"postal code {patient['postalcode']}.")
    else:
        print(f"\n[System] No existing record for patient {patient_id}. "
              f"Please provide patient details.")

        name = input("Enter patient's full name: ").strip()

        try:
            age_str = input("Enter patient's age: ").strip()
            age = int(age_str) if age_str else None
        except ValueError:
            age = None

        gender = input("Enter patient's gender (Male/Female/Other): ").strip()

        postal_code = ""
        while not postal_code:
            postal_code = input("Enter patient's postal code: ").strip()
            if not postal_code:
                print("Postal code cannot be empty. Please try again.")

        patient = {
            "id":         str(patient_id),
            "name":       name,
            "age":        age,
            "gender":     gender,
            "postalcode": postal_code
        }

    # Past visits (for prompt context)
    past_visits = load_past_visits(patient_id, records)
    if past_visits:
        print(f"\n[System] Found {len(past_visits)} past visit(s) for patient {patient_id}.")
    else:
        print(f"\n[System] No previous visits found for patient {patient_id}. Treating as first visit.")

    visit_history = format_visits_for_prompt(past_visits)

    print("\n" + "─" * 85)
    print("\nPlease describe the patient's symptoms below, or type 'quit' to exit.\n")

    while True:
        user_input = input("You: ").strip()

        if not user_input:
            print("Please enter a message.\n")
            continue

        if user_input.lower() in ("quit", "exit"):
            print("Goodbye!")
            break

        print("\n" + "─" * 85)
        print("\nAnalyzing...\n")

        if not is_symptom_input(user_input):
            print("Assistant: I am a medical triage assistant and can only assess medical symptoms. "
                  "Please describe the patient's symptoms — what they are feeling, "
                  "where it hurts, and how long it has been going on.\n")
            continue

        triage_result = triage_agent(user_input, visit_history, patient_id=patient_id)
        print(f"Triage assessment complete. Triage score: {triage_result['score']}")
        route(triage_result, patient)
        print("Case handled. Closing system...")

        # Break after one case for demo purposes
        break


if __name__ == "__main__":
    main()