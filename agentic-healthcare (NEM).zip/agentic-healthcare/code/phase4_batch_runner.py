"""
phase4_batch_runner.py — Batch privacy evaluation for agent1.

Run from the code/ directory:
    python phase4_batch_runner.py

What this does
--------------
Loads every scenario from scenarios.json, calls triage_agent() directly
(bypassing the interactive loop in main()), feeds every prompt-response
pair through the privacy_eval detectors, and writes one JSONL record per
scenario to ./logs/phase4_results.jsonl.

Phase 5 reads that file to produce statistics and charts.

Requirements
------------
- Ollama must be running locally (qwen2.5:7b loaded)
- triage.json must exist in code/
- dept_db/ (ChromaDB) must exist in code/
- privacy_eval/ package must be installed in code/
- config.yaml corpus_path should point to dept_corpus.txt
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Path setup — run from code/ so relative imports work
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(__file__))

from agent1 import (
    find_patient,
    format_visits_for_prompt,
    load_past_visits,
    load_triage_records,
    triage_agent,
)
from privacy_eval import PatientContext, PrivacyEvalRunner

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SCENARIOS_FILE  = "./scenarios.json"
TRIAGE_JSON     = "./triage.json"
CONFIG_PATH     = "./privacy_eval/config.yaml"
OUTPUT_LOG      = "./logs/phase4_results.jsonl"

# Patient ID to use for all scenarios. Must exist in triage.json so we get
# real demographics and visit history. Change to any valid ID in your file.
DEFAULT_PATIENT_ID = "17734153"

# How many times to run each scenario. qwen is non-deterministic at
# temperature > 0, so running each scenario more than once gives a better
# picture of leakage probability. Set to 1 for a quick first pass.
RUNS_PER_SCENARIO = 1

# Seconds to wait between Ollama calls to avoid overwhelming the local server.
SLEEP_BETWEEN_CALLS = 0.5


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_scenarios(path: str) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def build_synthetic_patient(patient_id: str) -> dict:
    """
    Fallback patient if patient_id is not found in triage.json.
    Uses realistic-looking but entirely fictional data.
    """
    return {
        "id":         patient_id,
        "name":       "Fiktiv Testpatient",
        "age":        55,
        "gender":     "Female",
        "postalcode": "2100",
    }


def run_scenario(
    scenario: dict,
    patient: dict,
    visit_history: str,
    all_records: list[dict],
    runner: PrivacyEvalRunner,
    run_number: int,
) -> dict:
    """
    Execute one scenario against triage_agent() and evaluate the response.
    Returns a result dict ready for writing to JSONL.
    """
    symptom_input = scenario["symptom_input"]

    # Call triage_agent directly — no interactive loop, no routing.
    result = triage_agent(
        user_input=symptom_input,
        visit_history=visit_history,
        patient_id=str(patient["id"]),
    )

    response      = result["response"]
    system_prompt = result["system_prompt"]
    user_prompt   = result["user_prompt"]
    visit_hist    = result["visit_history"]
    dept_context  = result["dept_context"]

    # Build the PatientContext the detectors need.
    context = PatientContext(
        patient_id=str(patient["id"]),
        name=patient.get("name", ""),
        age=patient.get("age"),
        gender=patient.get("gender", ""),
        postalcode=str(patient.get("postalcode", "")),
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        visit_history=visit_hist,
        dept_context=dept_context,
        all_records=all_records,
    )

    # Run all five detectors.
    eval_record = runner.evaluate(response=response, context=context)

    # Build a flat result dict for easy consumption by Phase 5.
    verdict_summary = {
        v.detector_id: {
            "verdict":    v.verdict,
            "evidence":   v.evidence[:3],   # cap at 3 examples per detector
            "confidence": v.confidence,
        }
        for v in eval_record.verdicts
    }

    fired_detectors = [
        v.detector_id for v in eval_record.verdicts if v.verdict == "fail"
    ]

    expected_fail   = scenario.get("expect_fail", [])
    true_positives  = [d for d in fired_detectors if d in expected_fail]
    false_positives = [d for d in fired_detectors if d not in expected_fail]
    false_negatives = [d for d in expected_fail if d not in fired_detectors]

    return {
        "run_id":          eval_record.run_id,
        "timestamp":       datetime.now(timezone.utc).isoformat(),
        "scenario_id":     scenario["scenario_id"],
        "leakage_type":    scenario["leakage_type"],
        "description":     scenario["description"],
        "run_number":      run_number,
        "patient_id":      str(patient["id"]),
        "triage_score":    result.get("score"),
        "symptom_snippet": symptom_input[:100],
        "response_snippet": response[:200],
        "overall_fail":    eval_record.overall_fail,
        "fired_detectors": fired_detectors,
        "expected_fail":   expected_fail,
        "true_positives":  true_positives,
        "false_positives": false_positives,
        "false_negatives": false_negatives,
        "verdicts":        verdict_summary,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    print("=" * 65)
    print("  Phase 4 — Batch Privacy Evaluation")
    print("=" * 65)

    os.makedirs(os.path.dirname(OUTPUT_LOG), exist_ok=True)

    # Load supporting data.
    scenarios   = load_scenarios(SCENARIOS_FILE)
    all_records = load_triage_records()
    runner      = PrivacyEvalRunner(config_path=CONFIG_PATH)

    # Resolve the patient to use for all scenarios.
    patient = find_patient(DEFAULT_PATIENT_ID, all_records)
    if patient:
        print(f"\nUsing patient ID {DEFAULT_PATIENT_ID}: "
              f"{patient.get('name')}, age {patient.get('age')}, "
              f"postal {patient.get('postalcode')}")
    else:
        patient = build_synthetic_patient(DEFAULT_PATIENT_ID)
        print(f"\n[WARNING] Patient ID {DEFAULT_PATIENT_ID} not found in triage.json. "
              f"Using synthetic fallback patient.")

    past_visits   = load_past_visits(str(patient["id"]), all_records)
    visit_history = format_visits_for_prompt(past_visits)

    print(f"Past visits loaded : {len(past_visits)}")
    print(f"Scenarios loaded   : {len(scenarios)}")
    print(f"Runs per scenario  : {RUNS_PER_SCENARIO}")
    print(f"Total LLM calls    : {len(scenarios) * RUNS_PER_SCENARIO}")
    print(f"Output log         : {OUTPUT_LOG}")
    print()

    total      = len(scenarios) * RUNS_PER_SCENARIO
    completed  = 0
    all_results: list[dict] = []

    # Open output file in append mode so partial runs are preserved.
    with open(OUTPUT_LOG, "w", encoding="utf-8") as out_f:

        for scenario in scenarios:
            for run_num in range(1, RUNS_PER_SCENARIO + 1):
                completed += 1
                print(f"  [{completed:03d}/{total:03d}] {scenario['scenario_id']} "
                      f"(run {run_num}) — {scenario['description'][:50]}...")

                try:
                    result = run_scenario(
                        scenario=scenario,
                        patient=patient,
                        visit_history=visit_history,
                        all_records=all_records,
                        runner=runner,
                        run_number=run_num,
                    )
                except Exception as e:
                    print(f"           [ERROR] {e}")
                    result = {
                        "scenario_id":  scenario["scenario_id"],
                        "run_number":   run_num,
                        "error":        str(e),
                        "overall_fail": False,
                    }

                fired = result.get("fired_detectors", [])
                status = f"LEAK ({', '.join(fired)})" if fired else "clean"
                print(f"           → {status}")

                all_results.append(result)
                out_f.write(json.dumps(result, ensure_ascii=False) + "\n")
                out_f.flush()

                time.sleep(SLEEP_BETWEEN_CALLS)

    # --- Summary ---
    total_runs  = len(all_results)
    total_leaks = sum(1 for r in all_results if r.get("overall_fail"))

    by_type: dict[str, dict] = {}
    for r in all_results:
        lt = r.get("leakage_type", "unknown")
        if lt not in by_type:
            by_type[lt] = {"runs": 0, "leaks": 0}
        by_type[lt]["runs"]  += 1
        by_type[lt]["leaks"] += 1 if r.get("overall_fail") else 0

    print("\n" + "=" * 65)
    print("  Phase 4 — Summary")
    print("=" * 65)
    print(f"  Total runs     : {total_runs}")
    print(f"  Total leaks    : {total_leaks}  ({total_leaks/total_runs*100:.1f}%)")
    print()
    print(f"  {'Scenario type':<20} {'Runs':>6} {'Leaks':>6} {'Rate':>8}")
    print(f"  {'-'*20} {'-'*6} {'-'*6} {'-'*8}")
    for lt, stats in sorted(by_type.items()):
        rate = stats["leaks"] / stats["runs"] * 100 if stats["runs"] else 0
        print(f"  {lt:<20} {stats['runs']:>6} {stats['leaks']:>6} {rate:>7.1f}%")

    print(f"\n  Results written to: {OUTPUT_LOG}")
    print("  Run phase5_statistics.py next to generate charts.")
    print("=" * 65)


if __name__ == "__main__":
    main()
